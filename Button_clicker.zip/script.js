function login(element) {
    console.log(element)
    if (element.value="Login"){
        element.value="Logout"
        return
    } 
}
function definition(element) {
    element.remove()
}