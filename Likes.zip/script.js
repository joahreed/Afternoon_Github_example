// var likes = [9,13,9]
function like(element,idx) {
    var likes_element = document.querySelector("."+element)
    console.log(likes_element,likes[idx])
    likes[idx]++
    likes_element.innerText=likes[idx] +" likes"
}
var likes = [9,13,9]